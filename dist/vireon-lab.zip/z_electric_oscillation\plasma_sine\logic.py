from experiments.z_electric_oscillation.shared_logic import run_electric as run
