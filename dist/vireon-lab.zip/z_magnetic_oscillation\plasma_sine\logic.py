from experiments.z_magnetic_oscillation.shared_logic import run_magnetic as run
